import React, { useState, useEffect, useCallback, useContext } from "react";
import "./Navbar.css";
import logo from "../Assets/logo.png";
import cart_icon from "../Assets/cart_icon.png";
import profile_icon from "../Assets/profile_icon.png";
import { Link, useNavigate } from "react-router-dom";
import { ShopContext } from "../../context/ShopContext";

const Navbar = () => {
  const [menu, setMenu] = useState("shop");
  const { getTotalCartItems } = useContext(ShopContext);
  const navigate = useNavigate();
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userName, setUserName] = useState("");
  // eslint-disable-next-line no-unused-vars
  const [userFullName, setUserFullName] = useState("");
  const [showDropdown, setShowDropdown] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  const updateLoginState = useCallback(() => {
    const loggedInUser = JSON.parse(localStorage.getItem("user"));
    if (loggedInUser) {
      setIsLoggedIn(true);
      setUserName(loggedInUser.name || "");
      setUserFullName(loggedInUser.fullName || "");
    } else {
      setIsLoggedIn(false);
      setUserName("");
      setUserFullName("");
    }
  }, []);

  useEffect(() => {
    updateLoginState();

    const handleAuthEvent = () => {
      updateLoginState();
    };

    window.addEventListener("authChange", handleAuthEvent);

    const handleStorageChange = (e) => {
      if (e.key === "user") {
        updateLoginState();
      }
    };
    window.addEventListener("storage", handleStorageChange);

    return () => {
      window.removeEventListener("authChange", handleAuthEvent);
      window.removeEventListener("storage", handleStorageChange);
    };
  }, [updateLoginState]);

  const handleLogoutClick = () => {
    localStorage.removeItem("user");
    const event = new Event("authChange");
    window.dispatchEvent(event);
    localStorage.setItem("user", JSON.stringify(null));
    navigate("/signup");
  };

  const toggleDropdown = () => {
    setShowDropdown((prev) => !prev);
  };

  const toggleMenu = () => {
    setIsMenuOpen((prev) => !prev);
  };

  const handleSearch = (e) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/search?query=${searchQuery}`);
    }
  };

  return (
    <div className="navbar">
      <div className="nav-logo">
        <img src={logo} alt="Logo" />
        <p>SILKSEW</p>
      </div>

      <div className="hamburger-menu" onClick={toggleMenu}>
        <span></span>
        <span></span>
        <span></span>
      </div>

      <ul className={`nav-menu ${isMenuOpen ? "active" : ""}`}>
        <li onClick={() => setMenu("shop")}>
          <Link style={{ textDecoration: "none" }} to="/">
            Shop
          </Link>
          {menu === "shop" && <hr />}
        </li>
        <li onClick={() => setMenu("mens")}>
          <Link style={{ textDecoration: "none" }} to="/mens">
            Men
          </Link>
          {menu === "mens" && <hr />}
        </li>
        <li onClick={() => setMenu("womens")}>
          <Link style={{ textDecoration: "none" }} to="/womens">
            Women
          </Link>
          {menu === "womens" && <hr />}
        </li>
        <li onClick={() => setMenu("kids")}>
          <Link style={{ textDecoration: "none" }} to="/kids">
            Kids
          </Link>
          {menu === "kids" && <hr />}
        </li>

        <li>
          <form className="nav-search-bar-mobile" onSubmit={handleSearch}>
            <input
              type="text"
              placeholder="Search..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <button type="submit">Go</button>
          </form>
        </li>
      </ul>

      <div className="nav-login-cart">
        {isLoggedIn ? (
          <>
            <Link to="/cart" className="cart-icon-wrapper">
              <img src={cart_icon} alt="Cart" className="cart-icon" />
              {getTotalCartItems() > 0 && (
                <div className="cart-item-count">{getTotalCartItems()}</div>
              )}
            </Link>

            <div className="profile-info">
              <div className="profile-info-container" onClick={toggleDropdown}>
                <span className="username-display">Hi , {userName}</span>
                <img
                  src={profile_icon}
                  alt="Profile"
                  className="profile-icon clickable"
                />
              </div>
              {showDropdown && (
                <div className="dropdown-menu">
                  <div
                    className="dropdown-item"
                    onClick={() => navigate("/profile")}
                  >
                    Profile
                  </div>
                  <div className="dropdown-item" onClick={handleLogoutClick}>
                    Logout
                  </div>
                </div>
              )}
            </div>
          </>
        ) : (
          <button onClick={() => navigate("/signup")} className="login-btn">
            Login
          </button>
        )}
      </div>
    </div>
  );
};

export default Navbar;