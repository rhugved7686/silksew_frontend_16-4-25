import React from "react";
import "./OfferBanner.css";

const ResponsiveMarquee = () => {
  return (
    <div className="marquee-container">
      <div className="marquee-content">
        <span>👜✨ FLAT 50% OFF on All Products! Limited Time Offer! ✨👜</span>
        <span>🛍️💎 Free Shipping on Orders Over $50! Shop Now 💎🛍️</span>
        <span>🎁🛒 Grab the Deal Before It's Gone! 🛒🎁</span>
        <span>🛍️🌟 Shop Your Favorites Today! 🌟🛍️</span>
        <span>👜🔥 Exclusive Discounts Await! 🔥👜</span>
      </div>
    </div>
  );
};

export default ResponsiveMarquee;
